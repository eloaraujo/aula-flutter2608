//criando a lista de frutas

import 'package:fruitstore/domain/fruit.dart';

final fruitMock = [
  Fruit("Banana", "R\$ 8,50"),
  Fruit("Uva", "R\$ 5,00"),
  Fruit("Maça", "R\$ 7,80"),
  Fruit("Pera", "R\$ 4,95"),
  Fruit("Manga", "R\$ 9,75")

];