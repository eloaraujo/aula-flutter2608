//classe que vai construit os objetos de fruta
class Fruit {
  String name;
  String price;

  Fruit(this.name, this.price);


}
