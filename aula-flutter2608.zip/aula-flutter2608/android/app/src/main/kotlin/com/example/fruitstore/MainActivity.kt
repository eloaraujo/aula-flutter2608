package com.example.fruitstore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
